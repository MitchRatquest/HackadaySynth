.. slip documentation master file, created by
   sphinx-quickstart on Thu Sep 10 21:17:54 2015.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

.. Copyright (c) 2017 Ruud de Jong
   This file is part of the SlipLib project which is released under the MIT license.
   See https://github.com/rhjdjong/SlipLib for details.

.. include:: ../README.rst


Contents
========

.. toctree::
   :maxdepth: 2
   
   module


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

