cp minty.config smartgear.config
sudo chown root:root sg_spi
sudo chmod 4755 sg_spi

